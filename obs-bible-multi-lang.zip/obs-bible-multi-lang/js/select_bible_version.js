function getSelectedBibleData() {
    let chosenBibleVersion = localStorage.getItem('saved-bible-version');
    const bibleVersions = {
        kjv: kjvBible,
        nkjv: nkjvBible,
        lo_segond: lo_segondBible,
    };

    return bibleVersions[chosenBibleVersion] || kjvBible;
}

function getBibleData(chosenBibleVersion) {
    const bibleVersions = {
        kjv: kjvBible,
        nkjv: nkjvBible,
        lo_segond: lo_segondBible,
    };

    return bibleVersions[chosenBibleVersion] || kjvBible;
}



function getSelectedVersion() {
    const selectBibleVersion = document.getElementById("bible-version");
    let chosenBibleVersion = localStorage.getItem('saved-bible-version') || selectBibleVersion.value || "kjv";

    const validVersions = ["kjv", "nkjv", "lo_segond"];
    return validVersions.includes(chosenBibleVersion) ? chosenBibleVersion : "kjv";
}

var bible_data = getSelectedBibleData();
