const booksOfTheBible = [
  "Genèse ", "Exode ", "Lévitique ", "Nombres ", "Deutéronome ",
  "Josué ", "Juges ", "Ruth ", "1 Samuel ", "2 Samuel ", "1 Rois ",
  "2 Rois ", "1 Chroniques ", "2 Chroniques ", "Esdras ", "Néhémie ",
  "Esther ", "Job ", "Psaume ", "Proverbes ",
  "Ecclésiaste ", "Cantique des Cantiques ", "Ésaïe ", "Jérémie ", "Lamentations ",
  "Ézékiel ", "Daniel ", "Osée ", "Joël ","Amos ",
  "Abdias ", "Jonas ", "Michée ", "Nahum ", "Habacuc ",
  "Sophonie ", "Aggée ", "Zacharie ", "Malachie ",
  "Matthieu ", "Marc ", "Luc ", "Jean ", "Actes ",
  "Romains ", "1 Corinthiens ", "2 Corinthiens ", "Galates ",
  "Éphésiens ", "Philippiens ", "Colossiens ", "1 Thessaloniciens ", "2 Thessaloniciens ",
  "1 Timothée ",  "2 Timothée ", "Tite ", "Philémon ", "Hébreux", "Jacques ", "1 Pierre ",
  "2 Pierre ", "1 Jean ", "2 Jean ", "3 Jean ", "Jude ", "Apocalypse "
];


const bibleInput = document.getElementById("bible-input");


const suggestionsList = document.getElementById("suggestions");
let selectedSuggestionIndex = -1; // Index of the currently selected suggestion


function updateInput(index) {
  if (index >= 0 && index < suggestionsList.children.length) {
    for (let item = suggestionsList.children.length - 1; item >= 0; item--) {
      suggestionsList.children[item].style.backgroundColor = "#222";
    }
    
    const selectedSuggestion = suggestionsList.children[index];
    bibleInput.value = selectedSuggestion.textContent;
    selectedSuggestion.style.backgroundColor = "#444";

    // Calculate the scroll position to ensure the selected item is visible
    const suggestionHeight = selectedSuggestion.offsetHeight;
    const scrollTop = selectedSuggestion.offsetTop - (suggestionHeight * 2); // Adjust as needed
    suggestionsList.scrollTop = scrollTop;
  }
}

bibleInput.addEventListener("input", function() {
  const inputValue = bibleInput.value.toLowerCase();
  const filteredBooks = booksOfTheBible.filter(book => book.toLowerCase().includes(inputValue));

  suggestionsList.innerHTML = "";

  filteredBooks.forEach((book, index) => {
    const listItem = document.createElement("li");
    listItem.textContent = book;
    // Add a click event listener to each suggestion
    listItem.addEventListener("click", () => {
      updateInput(index);
      suggestionsList.innerHTML = "";
    });
    suggestionsList.appendChild(listItem);
  });

  // Reset the selected suggestion index
  selectedSuggestionIndex = -1;
});

bibleInput.addEventListener("keydown", function(event) {
  if (event.key === "ArrowDown") {
    
    event.preventDefault();
    selectedSuggestionIndex =
      (selectedSuggestionIndex + 1) % suggestionsList.children.length;
    updateInput(selectedSuggestionIndex);
  } else if (event.key === "ArrowUp") {
    // Handle Arrow Up key press
    event.preventDefault();
    selectedSuggestionIndex =
      (selectedSuggestionIndex - 1 + suggestionsList.children.length) %
      suggestionsList.children.length;
    updateInput(selectedSuggestionIndex);
  } else if (event.key === "Enter") {
    // Handle Enter key press to clear suggestions
    event.preventDefault();
    suggestionsList.innerHTML = "";
  }
});